#include <iostream>
#include <list>
#include <iterator>
using namespace std;
void showlist(list <int> g)
{
list <int> :: iterator it;
for(it = g.begin(); it != g.end(); ++it)
cout << '\t' << *it;
cout << '\n';
}
int main()
{
list <int> l;
int y=0,x=0;
cout<<"donner la taille"<<endl;
cin >> y;
for (int i = 0; i < y; ++i)
{
   cout <<"donner la valuer :"<<i+1<<endl;
   cin >> x; 
   l.push_back(x);

}
cout << "\nvotre liste est : ";
showlist(l);

cout << "la liste tri� : ";
l.sort();
showlist(l);
return 0;
}
