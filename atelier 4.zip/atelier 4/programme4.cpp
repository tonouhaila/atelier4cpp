#include <iostream>
#include <list>
#include <cstring>
#include <iterator>

using namespace std;

class Personne {
public :
string nom;
string prenom;
string age ;
public :
Personne(string nom , string prenom ,string age ){
this->nom = nom ;
this->prenom = prenom;
this->age = age;
}
};
int main()
{
	string ag , N, P ;
	int n;
list<Personne> p;

cout<<"entrez la nombre des personnes  :  ",
cin>>n;
for (int i = 0; i < n; ++i)
{
     cout<<"donnez le nom de personne numero "<<i+1<<" : " ;
	 cin>>N;
	 cout<<"donnez le prenom de personne numero "<<i+1<<" : " ;
	 cin>>P;
	 cout<<"donnez l'age de personne numero "<<i+1<<" : " ;
	 cin>>ag;
	 cout<<endl;	 	
	p.push_back(Personne(N,P,ag));
}
list<Personne>::iterator it;

for (it = p.begin(); it != p.end(); ++it){
cout << it->nom <<"\t";
cout << it->prenom<<"\t";
cout << it->age<<endl;
}

return 0;
}